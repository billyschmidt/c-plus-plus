#include <iostream>
#include <limits>
#include <ostream>

int main()
{
   std::cout << "bits per int: " << std::numeric_limits<int>::digits << '\n';
}
