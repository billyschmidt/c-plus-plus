#include <iostream>
#include <ostream>

int main()
{
  using namespace std;
  int x = 42;

  cout << "x   = " << x   << "\n";
  cout << "++x = " << ++x << "\n";
  cout << "x   = " << x   << "\n";
  cout << "x++ = " << x++ << "\n";
  cout << "x   = " << x   << "\n";
}
