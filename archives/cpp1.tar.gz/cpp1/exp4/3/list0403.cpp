// Bill Schmidt 4159697
// adding a triangle

#include <iostream>
#include <ostream>

int main()
{
  std::cout << "Shape\t\tSides\n" << 
    "-----\t\t-----\n";
  std::cout << "Square\t\t" << 4 << '\n' <<
    "Circle\t\t?\n"
    "Triangle\t" << 3 << '\n';
}
