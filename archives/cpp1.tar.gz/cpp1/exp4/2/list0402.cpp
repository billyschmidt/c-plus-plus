// Bill Schmidt 4159697
// printing a double quote character

#include <iostream>
#include <ostream>

int main()
{
   std::cout << "\"\n";
}
