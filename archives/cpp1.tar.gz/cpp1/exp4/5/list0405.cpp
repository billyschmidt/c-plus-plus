// Bill Schmidt 4159697
// defining and printing empty string

#include <iostream>
#include <ostream>
#include <string>

int main()
{
  std::string empty;
  std::cout << "*" << empty << "*\n";
}
