/**
 * Bill Schmidt
 * 4159697
 *
 * driver for string_set class
 * 
 */


#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <list>
#include <string>
#include <locale>

#include "string_set.hpp"

// inline definitions for left, right, and parent
int inline left(int i)   { return (i*2); }
int inline right(int i)  { return (i*2 + 1); }
int inline parent(int i) { return (i/2); }


// returns true if the first string is lexically before the second
bool alphabetizer(std::string first, std::string second)
{
  int length1 = first.length();
  int length2 = second.length();
  int total = std::min(length1,length2);
  
  std::locale loc;
  
  if (first == second)
	{
	  return false;
	}
  
  for (int i(0); i < total; i++)
	{
	  if (tolower(first.at(i),loc) < tolower(second.at(i), loc))
		{	
		  return true;
		}
	  
	  if (tolower(first.at(i),loc) > tolower(second.at(i), loc))
		{	
		  return false;
		}
	}
  
  // loop breaks when it has fallen off the end, so the string with less is first
  if (length1 < length2)
	{
	  return true;
	}
  
  return false;
}



// maintain the heap property
void heapify(int i, std::string* A, int heapsize)
{
  int l = left(i);
  int r = right(i);
  int pos = i;
  
  //check left side
  if (l <= heapsize and alphabetizer(A[l], A[pos]))
	{
	  pos = left(i);
	}
  
  //check right side
  if (r <= heapsize and alphabetizer(A[r], A[pos]))
	{
	  pos = right(i);
	}
  
  //recurse and stop when root node isn't broken
  if (pos != i)
	{
	  std::swap(A[i],A[pos]);
	  heapify(pos,A,heapsize);
	}
}


std::string extract_first(std::string* A, int& heapsize)
{
  std::string ans = A[1];
  
  A[1] = A[heapsize];
  
  heapsize--;
  
  heapify(1, A, heapsize);
  
  return ans;
}



int main()
{
  // declare a single string_set of table size 1000
  
  string_set S(1000);
  
  //  
  // then read in strings (i.e. words) from the first file and put them in S 
  //  
  
  std::ifstream fin("first.txt");
  
  if (not fin)
	{
	  std::perror("first.txt");
	}
  
  else
    {
	  std::string word;
      
	  while (fin >> word)
		{
		  S.insert(word);
		}
	  fin.close();
    }
  
  //
  // then read in strings (i.e. words) from the second file and take those out of S. 
  //
  
  std::ifstream sin("second.txt");
  
  if (not sin)
	{
	  std::perror("second.txt");
	}
  
  else
    {
	  std::string word;
	  
	  while (sin >> word)
		{	
		  S.remove(word);
		}
	  
	  sin.close();
    }
  
  // output the words in S to standard output (i.e. std::cout).
  // std::cout << (std::string)S;
  
  //
  // take strings from S, and place in new array
  //  
  
  std::string* final;
  final = S.get_array();
  
  int array_size = S.get_size() + 1;
  
  //
  // sort it 
  //
  
  int floor = S.heapsize/2;
  
  for (int i(floor); i >= 1; i--)
	{
	  heapify(i, final, S.heapsize);
	}
  
  //  
  // print to cout
  //
  
  int start(1);
  
  while (start < array_size)
	{
	  std::cout << extract_first(final, S.heapsize) << '\n';
	  start += 1;
	}
}
