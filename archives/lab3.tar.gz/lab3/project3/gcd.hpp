#ifndef GCD_HPP_
#define GCD_HPP_

int gcd(int n, int m);

#endif
