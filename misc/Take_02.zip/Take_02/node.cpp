/**
 * Bill Schmidt
 * 4159697
 * Implementing a concrete singly linked list data structure
 *
 */
#include <iostream>
#include <ostream>

template<typename T>
struct Node 
{
	Node* next_;
	Node* head_; // maybe i'll use this?
	T value_;  
	
	Node(Node* list, T value)  		// constructor only called once when new Node created
		:next_(NULL), value_(value) // initialize next pointer to NULL, value to value
	{
		head_=NULL;
	} 
};

// add to beginning of list represented by the pointer list to its first Node
template<typename T>
	void push(Node<T>*& list, T value)
{
	// if list is null, make this list the new one
	if (list == NULL) 
		{
		list = new Node<T>(NULL, value); 		// create new list, set next pointer to null (cuz it's the only one)
		}
	
	Node<T>* temp = new Node<T>(list, value);	// list is not null, so make temp pointer looking at head
	temp -> value_ = value; 					// assign value to temp
	temp -> next_ = list; 						// point temp Node to list (head?)
	list = temp; 								// set head to newly created Node
}


// add value to the end of the Node represented by list
template<typename T>
	void append(Node<T>*& list, T value)
{
	if (list == NULL) 
		{
		// if list is null, make this the new Node
		list = new Node<T>(NULL, value); // create new list, set pointer to null
		} 
	
	// list is not not null, so make pointer curr to look around
	Node<T>* curr(list);  
	while (curr -> next_ != NULL) 
		{ 										// keep moving pointer until it hits the end
		curr = curr -> next_;
		}
	
	// breaking out of the while, we know next is null
	curr -> next_ = new Node<T>(NULL, value); 	// so make the new Node and set curr->next to be that guy. also can make the next point to null since it's at the end
}

// return the sum of all the elements of the list represented by list
template<typename T>
	T sum(Node<T>* list)
{
	int total(0);  								// initialize variable for getting total
	Node<T>* curr(list);  						// make current pointer looking at list
	
	while (curr)
		{  										// loop through,
		total += curr -> value_;  				// +='ing the values,
		curr = curr -> next_;  					// setting curr to curr -> next
		}
	return total; 								// return that bad boy
}

//write out the elements of the list each followed by a newline
template<typename T>
	std::ostream& operator<< (std::ostream& out, Node<T>* list)
{
	Node<T>* head = list;  						// made head pointer looking at list, head=list is same as head(list) is guess?
	while (head)
		{  										// loop while a head exists
		std::cout << head -> value_ << '\n'; 	// cout that sucker
		head = head -> next_; 					//  moving right along
		}
	return out;
	
}

// end of my stuff

//****************************************************************

int main(void)
{
	typedef Node<int>* list;
	using namespace std;
	list ls(0); //empty list
	push(ls, 0); //add zero to the front of the list
	push(ls, 1);
	push(ls, 2);
	push(ls, 3);
	push(ls, 100); 
	append(ls, -1); //add -1 to the far end of the list
	append(ls, -2);
	append(ls, -3);
	push(ls, 100);
	cout << "The list is:\n" << ls; //print the list one number per line
	cout << "and it's sum is " << sum(ls) << endl; //add up the list
	return 0;
	
}
